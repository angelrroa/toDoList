import './Components/main-menu/main-menu.js';
import './Components/forms/customer-form.js';
import {tabMenuPage}  from './js/controllers/customer-controller.js';
addEventListener("DOMContentLoaded", (event) => {
    tabMenuPage();
});